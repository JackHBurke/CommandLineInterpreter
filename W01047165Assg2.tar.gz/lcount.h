void addCounts(char *line);
