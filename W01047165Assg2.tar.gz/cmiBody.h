int checkInternal (char *cmd, char **args);
int cd (char *cmd, char **args);
void pwd (char *cmd);
void addToPath();
char **redirectionCheck(char **oldArgs);
